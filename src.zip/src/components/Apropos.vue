<template>
<div>
    <article>
          <img src="@/assets/amis.jpg" alt="amis"/>
<h2>Qui sommes-nous ?</h2>
        <p>L'équipe de développeurs et développeuses les 8 Fantastiques commença leur aventure en novembre 2021. Nous nous sommes principalement formé en autodidacte avant de nous spécialiser dans la formation de développeur(se) web et web mobile chez POP School.</p>

        <p>Situés à Strasbourg, nous vous proposons nos services dans toute la France, ainsi qu’à l’étranger en travail à distance pour accompagner des entreprises dans la création de leur site internet, la mise à jour ou l’optimisation de ceux-ci.</p>
    </article>
    <article>
            <h2>Rencontrez l'équipe</h2>
            <p>Notre fantastique team est composée de développeuses et développeurs compétent(e)s sur lesquels vous pouvez faire confiance : Fadoua, Marem, Sabrina, Cansu, Charles, Loïc, Thomas et Eliot.</p>
        </article>

<footer>
  Contactez-nous : 
  <a href="mailto:cansu.bl@hotmail.fr">Notre adresse mail</a>
</footer>
</div>   
     
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Staatliches&display=swap');

*{
background: rgb(59, 86, 97);
box-sizing: border-box;
margin: 5%;
color: white;
}
article {
        font-family: 'Staatliches', cursive;
        color: white;
        padding: 5%;
}
</style>
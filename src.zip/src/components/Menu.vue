<template>
  <div id="nav">
    <ul>
      <a href="./components/Accueil.vue">Accueil</a>    
    <a href="./Apropos.vue">À propos</a>    
    <a href="./MentionsLegales.vue">Mentions Légales</a>
    </ul>    

  </div>
</template>

<style scoped>
#nav {
  padding: 30px;
}
#nav a {
  font-weight: bold;
  color: #2c3e50;
}
#nav a.router-link-exact-active {
  color: white;
}
</style>